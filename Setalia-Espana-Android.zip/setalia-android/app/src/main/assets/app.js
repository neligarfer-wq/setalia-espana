const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function showPage(id) {
  $$('.page').forEach(p => p.classList.toggle('active', p.id === id));
  $$('nav button').forEach(b => b.classList.toggle('active', b.dataset.page === id));
  window.scrollTo({top: 0, behavior: 'smooth'});
  if (id === 'journal') renderFindings();
}

$$('[data-page]').forEach(b => b.addEventListener('click', () => showPage(b.dataset.page)));

const safety = $('#safety');
const check = $('#accept-check');
const accept = $('#accept-btn');
check.addEventListener('change', () => accept.disabled = !check.checked);
accept.addEventListener('click', () => {
  localStorage.setItem('setaliaSafetyAccepted', '1');
  safety.classList.add('hidden');
});
$('#open-safety').addEventListener('click', () => {
  check.checked = false; accept.disabled = true; safety.classList.remove('hidden');
});
if (localStorage.getItem('setaliaSafetyAccepted') === '1') safety.classList.add('hidden');

const camera = $('#camera-input');
camera.addEventListener('change', () => {
  const file = camera.files[0];
  if (!file) return;
  $('#preview').src = URL.createObjectURL(file);
  camera.parentElement.classList.add('has-image');
  $('#demo-analysis').disabled = false;
});
$('#demo-analysis').addEventListener('click', () => showPage('key'));

$$('#key-options button').forEach(button => button.addEventListener('click', () => {
  $$('#key-options button').forEach(b => b.classList.remove('selected'));
  button.classList.add('selected');
  $('#key-result').classList.remove('hidden');
}));

function getFindings() { return JSON.parse(localStorage.getItem('setaliaFindings') || '[]'); }
function renderFindings() {
  const items = getFindings();
  $('#findings').innerHTML = items.length ? items.map(x => `<article class="finding"><span>${escapeHtml(x.date)}</span><h3>${escapeHtml(x.name)}</h3><p>${escapeHtml(x.place)}</p><small>${escapeHtml(x.notes)}</small></article>`).join('') : '<div class="empty">Aún no has guardado ningún hallazgo.</div>';
}
function escapeHtml(value='') { const d=document.createElement('div'); d.textContent=value; return d.innerHTML; }
$('#finding-form').addEventListener('submit', e => {
  e.preventDefault();
  const items = getFindings();
  items.unshift({name: $('#finding-name').value, place: $('#finding-place').value, notes: $('#finding-notes').value, date: new Date().toLocaleDateString('es-ES')});
  localStorage.setItem('setaliaFindings', JSON.stringify(items));
  e.target.reset(); renderFindings();
});

if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
