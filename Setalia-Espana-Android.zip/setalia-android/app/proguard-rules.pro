# Reglas reservadas para futuras versiones con reconocimiento fotográfico.
