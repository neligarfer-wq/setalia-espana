# Setalia España para Android

Proyecto Android del prototipo 0.1.0. La APK generada es de prueba y utiliza una firma automática de depuración. Puede instalarse manualmente, pero no es la versión firmada para publicar en Google Play.

## Generar la APK en GitHub

1. Crear un repositorio vacío en GitHub.
2. Subir **el contenido de esta carpeta** a la raíz del repositorio.
3. Abrir la pestaña **Actions**.
4. Entrar en **Generar APK de Setalia**.
5. Cuando la ejecución termine en verde, abrirla y descargar el archivo **Setalia-Espana-APK** en el apartado Artifacts.
6. Descomprimir el archivo descargado e instalar `app-debug.apk` en Android.

La aplicación no realiza todavía reconocimiento automático de especies. Las fotografías y el cuaderno permanecen en el dispositivo.
